﻿namespace BMyPaint
{
    internal class MyLine
    {
        public int X1 { get; set; }
        public int Y1 { get; set; }
        public int X2 { get; set; }
        public int Y2 { get; set; }
        public Color Color { get; set; }
        public int Thickness { get; set; }
    }
}
