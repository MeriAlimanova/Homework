namespace BMyPaint
{
    public partial class MainForm : Form
    {
        int oldX, oldY;
        Color currentColor;

        List<MyLine> lines;

        public MainForm()
        {
            InitializeComponent();
            currentColor = Color.Black;
            ButtonColor.BackColor = currentColor;
            lines = new List<MyLine>();
        }

        private void PanelCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            Graphics gr = PanelCanvas.CreateGraphics();
            int x = e.X; int y = e.Y;

            int currentThickness;
            if (!Int32.TryParse(ComboThickness.Text, out currentThickness))
            {
                currentThickness = 4;
            }

            Pen myPen = new Pen(currentColor, currentThickness);
            gr.DrawLine(myPen, oldX, oldY, x, y);

            MyLine newLine = new MyLine()
            {
                X1 = oldX,
                Y1 = oldY,
                X2 = x,
                Y2 = y,
                Color = currentColor,
                Thickness = currentThickness
            };
            lines.Add(newLine);

            oldX = x; oldY = y;
        }

        private void PanelCanvas_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                oldX = e.X; oldY = e.Y;
            }
        }

        private void ButtonColor_Click(object sender, EventArgs e)
        {
            colorDialog.Color = currentColor;
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                currentColor = colorDialog.Color;
                ButtonColor.BackColor = currentColor;
            }
        }

        private void PanelCanvas_Paint(object sender, PaintEventArgs e)
        {
            foreach (MyLine line in lines)
            {
                Pen pen = new Pen(line.Color, line.Thickness);
                e.Graphics.DrawLine(pen, line.X1, line.Y1, line.X2, line.Y2);
            }
        }
    }
}
