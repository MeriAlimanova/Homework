﻿namespace BMyPaint
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PanelCanvas = new Panel();
            ButtonColor = new Button();
            colorDialog = new ColorDialog();
            ComboThickness = new ComboBox();
            SuspendLayout();
            // 
            // PanelCanvas
            // 
            PanelCanvas.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PanelCanvas.BackColor = Color.White;
            PanelCanvas.Location = new Point(12, 73);
            PanelCanvas.Name = "PanelCanvas";
            PanelCanvas.Size = new Size(776, 365);
            PanelCanvas.TabIndex = 0;
            PanelCanvas.Paint += PanelCanvas_Paint;
            PanelCanvas.MouseDown += PanelCanvas_MouseDown;
            PanelCanvas.MouseMove += PanelCanvas_MouseMove;
            // 
            // ButtonColor
            // 
            ButtonColor.Location = new Point(12, 12);
            ButtonColor.Name = "ButtonColor";
            ButtonColor.Size = new Size(94, 29);
            ButtonColor.TabIndex = 1;
            ButtonColor.UseVisualStyleBackColor = true;
            ButtonColor.Click += ButtonColor_Click;
            // 
            // ComboThickness
            // 
            ComboThickness.FormattingEnabled = true;
            ComboThickness.Items.AddRange(new object[] { "1", "2", "4", "6", "8", "12", "16", "20" });
            ComboThickness.Location = new Point(112, 13);
            ComboThickness.Name = "ComboThickness";
            ComboThickness.Size = new Size(81, 28);
            ComboThickness.TabIndex = 2;
            ComboThickness.Text = "4";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(ComboThickness);
            Controls.Add(ButtonColor);
            Controls.Add(PanelCanvas);
            Name = "MainForm";
            Text = "My Paint";
            ResumeLayout(false);
        }

        #endregion

        private Panel PanelCanvas;
        private Button ButtonColor;
        private ColorDialog colorDialog;
        private ComboBox ComboThickness;
    }
}
