﻿namespace AWinFormsPainting
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PanelCanvas = new Panel();
            ButtonLine = new Button();
            ButtonDrawRectangle = new Button();
            SuspendLayout();
            // 
            // PanelCanvas
            // 
            PanelCanvas.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PanelCanvas.BackColor = Color.White;
            PanelCanvas.Location = new Point(12, 59);
            PanelCanvas.Name = "PanelCanvas";
            PanelCanvas.Size = new Size(776, 379);
            PanelCanvas.TabIndex = 0;
            // 
            // ButtonLine
            // 
            ButtonLine.Location = new Point(12, 12);
            ButtonLine.Name = "ButtonLine";
            ButtonLine.Size = new Size(94, 29);
            ButtonLine.TabIndex = 1;
            ButtonLine.Text = "Line";
            ButtonLine.UseVisualStyleBackColor = true;
            ButtonLine.Click += ButtonLine_Click;
            // 
            // ButtonDrawRectangle
            // 
            ButtonDrawRectangle.Location = new Point(112, 12);
            ButtonDrawRectangle.Name = "ButtonDrawRectangle";
            ButtonDrawRectangle.Size = new Size(94, 29);
            ButtonDrawRectangle.TabIndex = 2;
            ButtonDrawRectangle.Text = "Rectangle";
            ButtonDrawRectangle.UseVisualStyleBackColor = true;
            ButtonDrawRectangle.Click += ButtonDrawRectangle_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(ButtonDrawRectangle);
            Controls.Add(ButtonLine);
            Controls.Add(PanelCanvas);
            Name = "MainForm";
            Text = "MainForm";
            ResumeLayout(false);
        }

        #endregion

        private Panel PanelCanvas;
        private Button ButtonLine;
        private Button ButtonDrawRectangle;
    }
}
