using System.Drawing.Drawing2D;
using System.Security.Cryptography.Xml;

namespace AWinFormsPainting
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void ButtonLine_Click(object sender, EventArgs e)
        {
            Graphics graphics;
            graphics = PanelCanvas.CreateGraphics();

            Pen myPen = new Pen(Color.Red, 4);
            int x1 = Random.Shared.Next(0, PanelCanvas.Width);
            int y1 = Random.Shared.Next(0, PanelCanvas.Height);
            int x2 = Random.Shared.Next(0, PanelCanvas.Width);
            int y2 = Random.Shared.Next(0, PanelCanvas.Height);

            graphics.DrawLine(myPen, x1, y1, x2, y2);
        }

        private void ButtonDrawRectangle_Click(object sender, EventArgs e)
        {
            Graphics graphics = PanelCanvas.CreateGraphics();

            int x1 = Random.Shared.Next(0, PanelCanvas.Width);
            int y1 = Random.Shared.Next(0, PanelCanvas.Height);
            int x2 = Random.Shared.Next(0, PanelCanvas.Width);
            int y2 = Random.Shared.Next(0, PanelCanvas.Height);

            Brush myBrush = new SolidBrush(Color.Blue);
            myBrush = new LinearGradientBrush(
                new Rectangle(x1, y1, x2 - x1, y2 - y1),
                Color.Yellow,
                Color.Red, 45);

            graphics.FillRectangle(myBrush, x1, y1, x2, y2);
        }
    }
}
